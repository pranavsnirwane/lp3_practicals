import java.util.*;

class fraknap {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of items: ");
        int n = scanner.nextInt();
        
        int[] weights = new int[n];
        int[] values = new int[n];
        
        System.out.println("Enter weights and values:");
        for (int i = 0; i < n; i++) {
            weights[i] = scanner.nextInt();
            values[i] = scanner.nextInt();
        }
        
        System.out.print("Enter knapsack capacity: ");
        int capacity = scanner.nextInt();
        scanner.close();
        
        double maxValue = maximizeValue(weights, values, capacity);
        System.out.println("Maximum value: " + maxValue);
    }

    private static double maximizeValue(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        double[][] items = new double[n][2]; // Store ratio and index
        
        for (int i = 0; i < n; i++)
            items[i] = new double[]{(double) values[i] / weights[i], i};

        Arrays.sort(items, (a, b) -> Double.compare(b[0], a[0]));

        double totalValue = 0;
        for (double[] item : items) {
            int idx = (int) item[1];
            if (capacity >= weights[idx]) {
                capacity -= weights[idx];
                totalValue += values[idx];
            } else {
                totalValue += item[0] * capacity;
                break;
            }
        }
        return totalValue;
    }
}
