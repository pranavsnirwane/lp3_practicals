import java.util.Scanner;

public class nqueen {
    static int N;           // Size of the chessboard (NxN)
    static int[][] board;   // Chessboard to represent queens' positions

    // Function to check if placing a queen at board[row][col] is safe
    static boolean isSafe(int row, int col) {
        // Check the column for any previous queens
        for (int i = 0; i < row; i++) if (board[i][col] == 1) return false;

        // Check upper-left diagonal for any previous queens
        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) if (board[i][j] == 1) return false;

        // Check upper-right diagonal for any previous queens
        for (int i = row, j = col; i >= 0 && j < N; i--, j++) if (board[i][j] == 1) return false;

        return true; // Return true if the position is safe
    }

    // Recursive function to solve the N-Queens problem
    static boolean solveNQueens(int row) {
        // If all queens are placed, print the solution
        if (row == N) {
            for (int[] r : board) { // Iterate through each row
                for (int c : r)       // Iterate through each column
                    System.out.print(c == 1 ? "Q " : ". "); // Print 'Q' for queen, '.' for empty
                System.out.println();  // Move to the next line after each row
            }
            return true; // Return true when a solution is found
        }

        // Try placing a queen in each column of the current row
        for (int col = 0; col < N; col++) {
            if (isSafe(row, col)) {  // Check if the queen can be placed safely
                board[row][col] = 1;  // Place the queen
                if (solveNQueens(row + 1)) return true; // Recur for the next row
                board[row][col] = 0;  // Backtrack if no solution is found
            }
        }

        return false; // Return false if no safe position is found
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Take the size of the board (N)
        System.out.print("Enter N: ");
        N = sc.nextInt();

        // Initialize the board
        board = new int[N][N];

        // Take input for the initial position of the first queen
        System.out.print("Enter first queen's row (0-based): ");
        int r = sc.nextInt();
        System.out.print("Enter first queen's col (0-based): ");
        int c = sc.nextInt();

        // Check if the initial position is valid
        if (r >= 0 && r < N && c >= 0 && c < N) {
            board[r][c] = 1;  // Place the first queen at the given position
            if (!solveNQueens(r + 1))  // Start solving from the next row
                System.out.println("No solution.");
        } else {
            System.out.println("Invalid position.");
        }

        sc.close(); // Close the scanner to prevent resource leak
    }
}
