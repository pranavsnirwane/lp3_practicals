import java.util.Scanner;

public class Knapsack01 {

    public static int knapSack(int capacity, int[] weights, int[] values, int n) {
        int[] dp = new int[capacity + 1];
        for (int i = 0; i < n; i++) {
            for (int w = capacity; w >= weights[i]; w--) {
                dp[w] = Math.max(dp[w], values[i] + dp[w - weights[i]]);
            }
        }
        return dp[capacity];
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of items: ");
        int n = scanner.nextInt();
        int[] weights = new int[n], values = new int[n];

        System.out.println("Enter weights and values:");
        for (int i = 0; i < n; i++) {
            weights[i] = scanner.nextInt();
            values[i] = scanner.nextInt();
        }

        System.out.print("Enter knapsack capacity: ");
        int capacity = scanner.nextInt();
        scanner.close();

        System.out.println("Maximum value: " + knapSack(capacity, weights, values, n));
    }
}
